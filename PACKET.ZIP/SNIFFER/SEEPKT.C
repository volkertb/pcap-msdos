/* 
 * Public domain by Russell Nelson, nelson@crynwr.com.  
 * Politeness dictates that you leave this notice intact.  
 * (well, I left it as he wanted :-)
 * Rewritten for DJGPP by Wojciech Galazka <wgalazka@chem.uw.edu.pl>
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <dos.h>
#include <ctype.h>
#include <dpmi.h>
#include <sys/movedata.h>
#include <sys/types.h>
#include "pktdrvr.h"

#define BUF_SIZE	2000

struct receiver_info recv_info;
volatile unsigned foo=0,f0=0,f1=0,f2=0;
// # of packets 
//foo	total
//f0	bad
//f1	incoming
//f2	processed

struct statistics stats,stats2;

typedef struct packets {
	char data[BUF_SIZE];
	int length;
} packets ;

struct packets current_packet;


void _receiver_start() {}
void receiver(_go32_dpmi_registers *r) 	       
{	
#define flag	r->x.ax
#define	handle	r->x.bx
#define _length	r->x.cx
#define	buf_seg	r->x.es
#define	buf_ofs	r->x.di
   	foo++;
  	if (flag == 0) {
	   	if (_length > recv_info.buffer_length || _length == 0) 
		{
	   		buf_seg=buf_ofs=0;
     			f0++;
	   		return;
		}
		if (recv_info.used == NUM_BUF)
			recv_info.used = 0;
		buf_seg=recv_info.seg[recv_info.used];
		buf_ofs=recv_info.ofs[recv_info.used];
		recv_info.packet_length[recv_info.used]=_length;
  		f1++;
	} else 
	{
		recv_info.used++; 
  		f2++;
	}
#undef flag	
#undef handle	
#undef length
#undef buf_seg	
#undef buf_ofs	
}
void _receiver_end() {}

void idle(void) {}

void DisplayAddress(const char *n)
{
	unsigned char a0,a1,a2,a3,a4,a5;
	a0=n[0];
	a1=n[1];
	a2=n[2];
	a3=n[3];
	a4=n[4];
	a5=n[5];
	printf("Ethernet address: %02x:%02x:%02x:%02x:%02x:%02x\n",
		a0,a1,a2,a3,a4,a5);
}

/* Convert byte to two ascii-hex characters */
static void ctohex(char *buf, int c)
{
	static char hex[] = "0123456789abcdef";
	*buf++ = hex[c >> 4];
	*buf = hex[c & 0xf];
}

void dump_bytes(char *bytes, int count)
{
	int n;
	int address;
	void fmtline();

	address = 0;
	while(count){
		n= (count > 16)? 16: count;
		fmtline(address,bytes,n);
		address += n;
		count -= n;
		bytes += n;
	}
}
/* Print a buffer up to 16 bytes long in formatted hex with ascii
 * translation, e.g.,
 * 0000: 30 31 32 33 34 35 36 37 38 39 3a 3b 3c 3d 3e 3f  0123456789:;<=>?
 */
void fmtline(int addr,char *buf,int len)
{
	char line[80];
	register char *aptr,*cptr;
	unsigned register char c;

	memset(line,' ',sizeof(line));
	ctohex(line,addr >> 8);
	ctohex(line+2,addr & 0xff);
	aptr = &line[6];
	cptr = &line[55];
	while(len-- != 0){
		c = *buf++;
		ctohex(aptr,c);
		aptr += 3;
		c &= 0x7f;
		*cptr++ = isprint(c) ? c : '.';
	}
	*cptr++ = '\n';
	fwrite(line,1,(unsigned)(cptr-line),stdout);
}

void DisplayStats(struct statistics *s2, struct statistics *s1)
{
	if (s2 == NULL)
		return;
	if (s1 == NULL) 
	{
		printf(" packets in   = %ld\n", s2->packets_in);	/* Totals across all handles */
		printf(" packets out  = %ld\n", s2->packets_out);
		printf(" bytes in     = %ld\n", s2->bytes_in);   	/* Including MAC headers */
		printf(" bytes out    = %ld\n", s2->bytes_out);
		printf(" errors in    = %ld\n", s2->errors_in);   /* Totals across all error types */
		printf(" errors out   = %ld\n", s2->errors_out);
		printf(" packets lost = %ld\n", s2->packets_lost);	/* No buffer from receiver(), card */
		return;
	}
	printf(" packets in   = %ld\n", s2->packets_in   - s1->packets_in);	
	printf(" packets out  = %ld\n", s2->packets_out  - s1->packets_out);
	printf(" bytes in     = %ld\n", s2->bytes_in     - s1->bytes_in);   	
	printf(" bytes out    = %ld\n", s2->bytes_out    - s1->bytes_out);
	printf(" errors in    = %ld\n", s2->errors_in    - s1->errors_in);   
	printf(" errors out   = %ld\n", s2->errors_out   - s1->errors_out);
	printf(" packets lost = %ld\n", s2->packets_lost - s1->packets_lost);	
}

extern void filter(char *cp, u_int pktlen);

void do_it()
{
	struct param par;
	short version, class, type, number, basic;
	char name[PKT_NAME_LENGTH] ;
	short handle;
	int num;
	short pktint[MAX_PKTS];
	char myeaddr[6];			/* our Ethernet address */
	short intno,oldmode;			/* our intno */
	
	if ((num=driver_installed(pktint)) >0)
	{
		fprintf(stdout, "Number of packet drivers found %d\n",num);
		intno = pktint[0];
	} else {
		fprintf(stderr, "No packet driver found\n");
		goto end;
	}

	recv_info.receiver = receiver;
	recv_info.start = _receiver_start;
	recv_info.end = _receiver_end;
	recv_info.buffer_length = BUF_SIZE;

	/* get a handle so that we can receive packets */
	if ((handle = access_type(intno,
		CL_ETHERNET,	/* has to be an Ethernet driver */
		ANYTYPE,	/* we don't care whose it is. */
		0,		/* we want the first piece of hardware */
		NULL,		/* doesn't matter because we want all */
		0,		/* zero type length, that is, all. */
		&recv_info)) == -1)	/* -> our upcall */
	{
		fprintf(stderr, "Error: access type\n%s\n",PacketErrorDescr());
		goto end;
	}	
	if (driver_info(intno,handle, &version, &class, &type, &number, name, &basic) == -1)
		fprintf(stderr, "Error: driver_info\n%s\n",PacketErrorDescr());
	else 
		printf("version: %d class: %d type: %d number: %d name: %s basic: %d\n\n", 
		        version,   class,    type,    number,    name,    basic );

	if (basic >= FUNC_HIGH)
		if (get_parameters(intno, &par) == -1)
			fprintf(stderr, "Warning: get_parameters\n%s\n",PacketErrorDescr());

	/* get the adaptor's Ethernet address */
	if (get_address (intno,handle,myeaddr,sizeof myeaddr) == -1)
		fprintf(stderr, "Error: get_address\n%s\n",PacketErrorDescr());
	else	
		DisplayAddress(myeaddr);

	/* put the interface into promiscuous mode */
	if ((oldmode = set_mode(intno,handle,RECV_PROMISCUOUS)) == -1)
		fprintf(stderr, "Warning: set_mode\n%s\n",PacketErrorDescr());

	if (get_statistics(intno,handle, &stats) == -1)
		fprintf(stderr, "Warning: getstatistics\n%s\n",PacketErrorDescr());

	while (!kbhit()) {
		if(recv_info.used != recv_info.last) {
			current_packet.length=
				recv_info.packet_length[recv_info.last];

       		dosmemget(OFFSET(recv_info.seg[recv_info.last], 
				recv_info.ofs[recv_info.last]),
				current_packet.length,
     				current_packet.data);

			filter(	current_packet.data,
				current_packet.length);

        	 	recv_info.last++;
			if (recv_info.last == NUM_BUF) 
				recv_info.last = 0;
			idle();
     		}
	}
	printf("Packets: total %d, discarded %d, allocated %d, processed %d\n",
		foo/2,f0,f1,f2);

	if (get_statistics(intno,handle, &stats2) == -1)
		fprintf(stderr, "Warning: getstatistics\n%s\n",
			PacketErrorDescr());
	else
		DisplayStats(&stats2,&stats);

	if (set_mode(intno,handle,oldmode) == -1)
		fprintf(stderr, "Warning: setmode\n%s\n",PacketErrorDescr());

	if (release_type(intno, handle) == -1)
		fprintf(stderr,"Error: releasetype\n%s\n",PacketErrorDescr());
end:
}

