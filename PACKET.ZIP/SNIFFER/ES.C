/* A slightly modified version of sniffer.c for SunOs 4.1.3 */
/* Changes copyright by Wojciech Galazka , 1997 */
/* released for free use under GPL */

#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h> 

#include <sys/time.h>
#include <sys/file.h>
#include <sys/signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
 
#include <net/if.h>
 
#include <netinet/in.h>
#include <netinet/if_ether.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <netinet/udp.h>
#include <netinet/ip_var.h>
#include <netinet/udp_var.h>
#include <netinet/tcp.h>
#include <netinet/ip_icmp.h>
 
#include <netdb.h>
#include <arpa/inet.h>
 
#define ERR stderr

#define IPPORT_LOGINSERVER	513
#define IPPORT_TELNET		23
#define IPPORT_SMTP 		25
#define IPPORT_FTP 		21
 
char    *malloc();
char    *device,
        *LogName;
FILE    *LOG;
int     debug=0;
 
#define CHUNKSIZE   4096        /* device buffer size */
int     if_fd = -1;
int     Packet[CHUNKSIZE+32];
 
void Pexit(err,msg)
int err; char *msg;
{ perror(msg);
  exit(err); }
 
void Zexit(err,msg)
int err; char *msg;
{ fprintf(ERR,msg);
  exit(err); }
 
#define IP          ((struct ip *)Packet)
#define IP_OFFSET   (0x1FFF)
#define SZETH       (sizeof(struct ether_header))
#define IPLEN       (ntohs(ip->ip_len))
#define IPHLEN      (ip->ip_hl)
#define TCPOFF      (tcph->th_off)
#define IPS         (ip->ip_src)
#define IPD         (ip->ip_dst)
#define TCPS        (ntohs(tcph->th_sport))
#define TCPD        (ntohs(tcph->th_dport))
#define IPeq(s,t)   ((s).s_addr == (t).s_addr)
 
#define TCPFL(FLAGS) (tcph->th_flags & (FLAGS))
 
#define MAXBUFLEN  (1024)
time_t  LastTIME = 0;
 
struct CREC {
     struct CREC *Next,
                 *Last;
     time_t  Time;              /* start time */
     struct in_addr SRCip,
                    DSTip;
     u_int   SRCport,           /* src/dst ports */
             DSTport;
     u_char  Data[MAXBUFLEN+2]; /* important stuff :-) */
     u_int   Length;            /* current data length */
     u_int   PKcnt;             /* # pkts */
     u_long  LASTseq;
};
 
struct CREC *CLroot = NULL;

char *inet_ntoa(struct in_addr in)
{
	static char buf[18];
        int in2=ntohl(*(long *)&in);
	u_char *m = (char *)&in2;
	u_char a=m[0];
	u_char b=m[1];
	u_char c=m[2];
	u_char d=m[3];
	sprintf(buf,"%02d%02d%02d%02d",a,b,c,d);
	return (buf);
}
 
char *Symaddr(ip)
  struct in_addr ip;
{ /*  struct hostent *he =
      gethostbyaddr((char *)&ip.s_addr, sizeof(struct in_addr),AF_INET);
 
  return( (he)?(he->h_name):(inet_ntoa(ip)) ); */
  return( inet_ntoa(ip) );
}
 
char *TCPflags(flgs)
  u_char flgs;
{ static char iobuf[8];
#define SFL(P,THF,C) iobuf[P]=((flgs & THF)?C:'-')
 
  SFL(0,TH_FIN, 'F');
  SFL(1,TH_SYN, 'S');
  SFL(2,TH_RST, 'R');
  SFL(3,TH_PUSH,'P');
  SFL(4,TH_ACK, 'A');
  SFL(5,TH_URG, 'U');
  iobuf[6]=0;
  return(iobuf);
}
 
char *SERVp(port)
  u_int port;
{ static char buf[10];
    char *p;
 
   switch(port) {
     case IPPORT_LOGINSERVER: p="rlogin"; break;
     case IPPORT_TELNET:      p="telnet"; break;
     case IPPORT_SMTP:        p="smtp"; break;
     case IPPORT_FTP:         p="ftp"; break;
     default: sprintf(buf,"%u",port); p=buf; break;
   }
   return(p);
}

 
char *Ptm(t)
  time_t *t;
{   char *p = ctime(t);
  p[strlen(p)-6]=0; /* strip " YYYY\n" */
  return(p);
}
 
char *NOWtm()
{ time_t tm;
  time(&tm);
  return( Ptm(&tm) );
}
 
#define MAX(a,b) (((a)>(b))?(a):(b))
#define MIN(a,b) (((a)<(b))?(a):(b))
 
/* add an item */
#define ADD_NODE(SIP,DIP,SPORT,DPORT,DATA,LEN) { \
    struct CREC *CLtmp = \
        (struct CREC *)malloc(sizeof(struct CREC)); \
  time( &(CLtmp->Time) ); \
  CLtmp->SRCip.s_addr = SIP.s_addr; \
  CLtmp->DSTip.s_addr = DIP.s_addr; \
  CLtmp->SRCport = SPORT; \
  CLtmp->DSTport = DPORT; \
  CLtmp->Length = MIN(LEN,MAXBUFLEN); \
  bcopy( (u_char *)DATA, (u_char *)CLtmp->Data, CLtmp->Length); \
  CLtmp->PKcnt = 1; \
  CLtmp->Next = CLroot; \
  CLtmp->Last = NULL; \
  CLroot = CLtmp; \
}
 
  struct CREC *GET_NODE(Sip,SP,Dip,DP)
  struct in_addr Sip,Dip;
  u_int SP,DP;
{   struct CREC *CLr = CLroot;
 
  while(CLr != NULL) {
    if( (CLr->SRCport == SP) && (CLr->DSTport == DP) &&
        IPeq(CLr->SRCip,Sip) && IPeq(CLr->DSTip,Dip) )
            break;
    CLr = CLr->Next;
  }
  return(CLr);
}
 
#define ADDDATA_NODE(CL,DATA,LEN) { \
 bcopy((u_char *)DATA, (u_char *)&CL->Data[CL->Length],LEN); \
 CL->Length += LEN; \
}
 
#define PR_DATA(dp,ln) {    \
    u_char lastc=0; \
  while(ln-- >0) { \
     if(*dp < 32) {  \
        switch(*dp) { \
            case '\0': if((lastc=='\r') || (lastc=='\n') || lastc=='\0') \
                        break; \
            case '\r': \
            case '\n': fprintf(LOG,"\n     : "); \
                        break; \
            default  : fprintf(LOG,"^%c", (*dp + 64)); \
                        break; \
        } \
     } else { \
        if(isprint(*dp)) fputc(*dp,LOG); \
        else fprintf(LOG,"(%d)",*dp); \
     } \
     lastc = *dp++; \
  } \
  fflush(LOG); \
}
 
void END_NODE(CLe,d,dl,msg)
  struct CREC *CLe;
  u_char *d;
  int dl;
  char *msg;
{
   fprintf(LOG,"\n-- TCP/IP LOG -- TM: %s --\n", Ptm(&CLe->Time));
   fprintf(LOG," PATH: %s(%s) =>", Symaddr(CLe->SRCip),SERVp(CLe->SRCport));
   fprintf(LOG," %s(%s)\n", Symaddr(CLe->DSTip),SERVp(CLe->DSTport));
   fprintf(LOG," STAT: %s, %d pkts, %d bytes [%s]\n",
                        NOWtm(),CLe->PKcnt,(CLe->Length+dl),msg);
   fprintf(LOG," DATA: ");
    {   u_int i = CLe->Length;
        u_char *p = CLe->Data;
      PR_DATA(p,i);
      PR_DATA(d,dl);
    }
 
   fprintf(LOG,"\n-- \n");
   fflush(LOG);
 
   if(CLe->Next != NULL)
    CLe->Next->Last = CLe->Last;
   if(CLe->Last != NULL)
    CLe->Last->Next = CLe->Next;
   else
    CLroot = CLe->Next;
   free(CLe);
}
 
/* 30 mins (x 60 seconds) */
#define IDLE_TIMEOUT 1800
#define IDLE_NODE() { \
  time_t tm; \
  time(&tm); \
  if(LastTIME<tm) { \
       struct CREC *CLe,*CLt = CLroot; \
     LastTIME=(tm+IDLE_TIMEOUT); tm-=IDLE_TIMEOUT; \
     while((CLe=CLt)) { \
       CLt=CLe->Next; \
       if(CLe->Time <tm) \
           END_NODE(CLe,(u_char *)NULL,0,"IDLE TIMEOUT"); \
     } \
  } \
}
 
void filter(char *cp, u_int pktlen)
{
	struct ip     *ip;
	struct tcphdr *tcph;
 
 	u_short EtherType=ntohs(((struct ether_header *)cp)->ether_type);
 
   	if (EtherType < 0x600) {
     		EtherType = *(u_short *)(cp + SZETH + 6);
     		cp+=8; pktlen-=8;
   	}

	if(debug) {
		fprintf(LOG,"type %s", 
		   	(EtherType == ETHERTYPE_IP) ? "IP\n": 
		   	(EtherType == ETHERTYPE_ARP) ? "ARP\n": 
		   	(EtherType == ETHERTYPE_REVARP) ? "RARP\n":"??\n"); 

	 }

   	if (EtherType != ETHERTYPE_IP) /* chuk it if its not IP */
      		return;
 
	/* ugh, gotta do an alignment :-( */
	bcopy(cp + SZETH, (char *)Packet,(int)(pktlen - SZETH));
 
	ip = (struct ip *)Packet;

	if(debug) {
		fprintf(LOG," version %04d", 		ip->ip_v);	 /* version */
		fprintf(LOG," header length %04d", 	ip->ip_hl);  /* header length */
		fprintf(LOG," TOS %04d\n", 		ip->ip_tos); /* type of service */
		fprintf(LOG," total length %04d", 	ntohs(ip->ip_len)); /* total length */
		fprintf(LOG," identification %04d", 	ntohs(ip->ip_id));  /* identification */
		fprintf(LOG," fragment offset %04d\n", 	ntohs(ip->ip_off)); /* fragment offset field */
		fprintf(LOG," TTL %04d", 		ip->ip_ttl); /* time to live */
		fprintf(LOG," protocol %04d",		ip->ip_p); 	 /* protocol */
		fprintf(LOG," checksum %04d\n", 	ip->ip_sum); /* checksum */
	}

	if(debug) {
		fprintf(LOG,"\t protocol %s", 
		   	(ip->ip_p == IPPROTO_TCP) ? "TCP\n":
		   	(ip->ip_p == IPPROTO_ICMP) ? "ICMP\n":
		   	(ip->ip_p == IPPROTO_UDP) ? "UDP\n":"??\n"); 
	 }

	if (ip->ip_p != IPPROTO_TCP) /* chuk non tcp pkts */
		return;

	
	tcph = (struct tcphdr *)(Packet + IPHLEN);

	if(debug) {
		fprintf(LOG,"\t source port %04d %04d",	tcph->th_sport,
				ntohs(tcph->th_sport));	/* source port */
		fprintf(LOG," dest port %04d %04d",	tcph->th_dport,
				ntohs(tcph->th_dport));	/* destination port */
		fprintf(LOG," seq number %04ld\n",	tcph->th_seq);  	/* sequence number */
		fprintf(LOG,"\t ack number %04ld",	tcph->th_ack);  	/* acknowledgement number */
		fprintf(LOG," data offset %04d",	tcph->th_off); 	/* data offset */
		fprintf(LOG," flags %04d (",		tcph->th_flags);	/* flags */ 
		if (tcph->th_flags & TH_FIN)	fprintf(LOG,"FIN"); 
		if (tcph->th_flags & TH_SYN)	fprintf(LOG,"SYN"); 
		if (tcph->th_flags & TH_RST)	fprintf(LOG,"RST"); 
		if (tcph->th_flags & TH_PUSH)	fprintf(LOG,"PUSH"); 
		if (tcph->th_flags & TH_ACK)	fprintf(LOG,"ACK"); 
		if (tcph->th_flags & TH_URG)	fprintf(LOG,"URG"); 
		fprintf(LOG,")\n\t window %04d",	tcph->th_win); 	/* window */
		fprintf(LOG," checksum %04d",		tcph->th_sum); 	/* checksum */
		fprintf(LOG," urgent ptr %04d\n",	tcph->th_urp); 	/* urgent pointer */
	 }

	if (!( (TCPD == IPPORT_TELNET) ||
       		(TCPD == IPPORT_LOGINSERVER) ||
       		(TCPD == IPPORT_FTP)
		)) return;
 
	{
	struct CREC *CLm;
     	int length = ((IPLEN - (IPHLEN * 4)) - (TCPOFF * 4));
     	u_char *p = (u_char *)Packet;
	p += ((IPHLEN * 4) + (TCPOFF * 4));
 
	if(debug) {
		fprintf(LOG,"PKT: (%s %04X) ", TCPflags(tcph->th_flags),length);
		fprintf(LOG,"%s[%s] => ", inet_ntoa(IPS),SERVp(TCPS));
		fprintf(LOG,"%s[%s]\n", inet_ntoa(IPD),SERVp(TCPD));
	 }
 
	if ((CLm = GET_NODE(IPS, TCPS, IPD, TCPD)) ) {
		CLm->PKcnt++;
		if (length>0)
        		if ((CLm->Length + length) < MAXBUFLEN ) {
          			ADDDATA_NODE( CLm, p,length);
	        	} else {
        	  		END_NODE( CLm, p,length, "DATA LIMIT");
			}
 
      		if (TCPFL(TH_FIN|TH_RST)) {
          		END_NODE( CLm, (u_char *)NULL,0,TCPFL(TH_FIN)?"TH_FIN":"TH_RST" );
		}
 
	 } else {
		if (TCPFL(TH_SYN)) {
			ADD_NODE(IPS,IPD,TCPS,TCPD,p,length);
		}
	 }
	
	IDLE_NODE();
	}
 
}
 
/* signal handler
 */
void death()
{   struct CREC *CLe;
 
    while((CLe=CLroot))
        END_NODE( CLe, (u_char *)NULL,0, "SIGNAL");
 
    fprintf(LOG,"\nLog ended at => %s\n",NOWtm());
    fflush(LOG);
    if(LOG != stdout)
        fclose(LOG);
    exit(1);
}
 
/* opens network interface, performs ioctls and reads from it,
 * passing data to filter function
 */
extern void do_it(void);

static char ss[2];

void main(argc, argv)
int argc;
char **argv;
{
    int   ac=1;
  
    LOG=NULL;
    device=NULL;
    while((ac<argc) && (argv[ac][0] == '-')) {
         char ch = argv[ac++][1];
       switch(toupper(ch)) {
            case 'I': device=argv[ac++];
                      break;
            case 'F': if(!(LOG=fopen((LogName=argv[ac++]),"a")))
                         Zexit(1,"Output file cant be opened\n");
                      break;
            case 'D': debug=1;
                      break;
            default : fprintf(ERR,
                        "Usage: %s [-d] [-i interface] [-f file]\n",
                            argv[0]);
                      exit(1);
       }
    }
 
    if(!device) {
        device=&ss[0];
        strcpy(device,"0");  //first NIC;
    }

    fprintf(ERR,"Using logical device %s, ",device);
    fprintf(ERR,"output to %s.%s\n",(LOG)?LogName:"stdout",
            (debug)?" (debug)":"");
 
    if(!LOG)
        LOG=stdout;
 
    signal(SIGINT, death);
    signal(SIGTERM,death);
    signal(SIGKILL,death);
    signal(SIGQUIT,death);
  
    fprintf(LOG,"\nLog started at => %s [pid %d]\n",NOWtm(),getpid());
    fflush(LOG);

    do_it();
    death();	
}
