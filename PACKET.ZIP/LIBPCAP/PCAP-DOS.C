/*
 * Copyright (c) 1990, 1991, 1992, 1993, 1994, 1995, 1996
 *	The Regents of the University of California.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that: (1) source code distributions
 * retain the above copyright notice and this paragraph in its entirety, (2)
 * distributions including binary code include the above copyright notice and
 * this paragraph in its entirety in the documentation or other materials
 * provided with the distribution, and (3) all advertising materials mentioning
 * features or use of this software display the following acknowledgement:
 * ``This product includes software developed by the University of California,
 * Lawrence Berkeley Laboratory and its contributors.'' Neither the name of
 * the University nor the names of its contributors may be used to endorse
 * or promote products derived from this software without specific prior
 * written permission.
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 *
 * The pcap-nit.c file was used as a skeleton to develop a packet
 * driver handling interface.
 * Wojciech Galazka <wgalazka@chem.uw.edu.pl>
 * Copyright (c) 1997
 * Wojciech Galazka <wgalazka@chem.uw.edu.pl>  All rights reserved.
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */

#ifndef lint
static const char rcsid[] =
    "@(#) $Header: pcap-dos.c,v 1.31 96/12/10 23:15:01 leres Exp $ (LBL)";
#endif
#include "pcap-dos.h"
#include <sys/types.h>
#include <sys/time.h>
#include <sys/timeb.h>
#include <sys/file.h>
//#include <sys/ioctl.h>
#include <sys/socket.h>

#include <net/if.h>

#include <netinet/in.h>
#include <netinet/in_systm.h>
#include <netinet/ip.h>
#include <netinet/if_ether.h>
#include <netinet/ip_var.h>
#include <netinet/udp.h>
#include <netinet/udp_var.h>
#include <netinet/tcp.h>
#include <netinet/tcpip.h>

#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "pcap-int.h"

#include "gnuc.h"
#ifdef HAVE_OS_PROTO_H
#include "os-proto.h"
#endif

#define DEVICE_MAGIC_NUMBER 	0xdeadbeef
#define MAX_DEVICES         	4*MAX_PKTS
#define PACKET_BUF_SIZE		2048		// DON'T CHANGE

/* Convert byte to two ascii-hex characters */
static void ctohex(char *buf, int c)
{
	static char hex[] = "0123456789abcdef";
	*buf++ = hex[c >> 4];
	*buf = hex[c & 0xf];
}

void dump_bytes(char *bytes, int count)
{
	int n;
	int address;
	void fmtline();

	address = 0;
	while(count){
		n= (count > 16)? 16: count;
		fmtline(address,bytes,n);
		address += n;
		count -= n;
		bytes += n;
	}
}
/* Print a buffer up to 16 bytes long in formatted hex with ascii
 * translation, e.g.,
 * 0000: 30 31 32 33 34 35 36 37 38 39 3a 3b 3c 3d 3e 3f  0123456789:;<=>?
 */
void fmtline(int addr,char *buf,int len)
{
	char line[80];
	register char *aptr,*cptr;
	unsigned register char c;

	memset(line,' ',sizeof(line));
	ctohex(line,addr >> 8);
	ctohex(line+2,addr & 0xff);
	aptr = &line[6];
	cptr = &line[55];
	while(len-- != 0){
		c = *buf++;
		ctohex(aptr,c);
		aptr += 3;
		c &= 0x7f;
		*cptr++ = isprint(c) ? c : '.';
	}
	*cptr++ = '\n';
	fwrite(line,1,(unsigned)(cptr-line),stdout);
}

static struct device_descr            	// full device info
{
  int eth;           			// device id
  int valid;         			// entry is valid
  int intno;         			// intr number
  int handle;        			// handle to the device
  int oldmode;       			// previous mode
  int mode;          			// current mode
  char name[8]; 		     	// device name
  struct receiver_info recv_info;     	// receiver info
} devices[MAX_DEVICES]; 		// up to eight devices


static void restore_mode(void)
{
   int i;
   struct device_descr *d;
   for (i=0; i< MAX_DEVICES; i++)
   {
      d = &devices[i];
      if (d->valid !=DEVICE_MAGIC_NUMBER)
         continue;
      set_mode(d->intno,d->handle,d->oldmode);
      release_type(d->intno, d->handle);
      d->valid=d->eth=0;
   }
   return;
}

int
pcap_stats(pcap_t *p, struct pcap_stat *ps)
{
   *ps = p->md.stat;
   return (0);
}

#define flag	r->x.ax
#define	handle	r->x.bx
#define _length	r->x.cx
#define	buf_seg	r->x.es
#define	buf_ofs	r->x.di

void receiver_null_start() {}
void receiver_null(_go32_dpmi_registers *r)
{
        buf_seg=buf_ofs=0;
}
void receiver_null_end() {}

#define RECEIVER(num)							\
void receiver_##num##_start() {}					\
void receiver_##num##(_go32_dpmi_registers *r) 	       			\
{									\
	struct receiver_info *ri = &devices[num].recv_info;		\
  	if (flag == 0) {						\
		if (_length > ri->buffer_length || _length == 0) {	\
	   		buf_seg=buf_ofs=0;				\
	   		return;						\
		}							\
									\
		if (ri->used == NUM_BUF)				\
			ri->used = 0;					\
		buf_seg=ri->seg[ri->used];				\
		buf_ofs=ri->ofs[ri->used];				\
		ri->packet_length[ri->used]=_length;			\
	} else 								\
		ri->used++;						\
}									\
void receiver_##num##_end() {}						\

RECEIVER(0)
RECEIVER(1)
RECEIVER(2)
RECEIVER(3)
RECEIVER(4)
RECEIVER(5)
RECEIVER(6)
RECEIVER(7)

#undef flag
#undef handle
#undef _length
#undef buf_seg
#undef buf_ofs

int pkt_read(int fd, char *buffer, int bufsize, int *total_len)
{
	struct device_descr   *d = &devices[fd];
	struct receiver_info *ri = &devices[fd].recv_info;
	if (bufsize == 0) return 0;
	if (bufsize < 0) return -1;
	if (d->valid !=DEVICE_MAGIC_NUMBER) return -1;

	if (ri->used != ri->last) {
		if (bufsize > ri->packet_length[ri->last])
		    bufsize = ri->packet_length[ri->last];
		dosmemget(OFFSET(ri->seg[ri->last],
				ri->ofs[ri->last]),
				bufsize,
				buffer);
		*total_len = ri->packet_length[ri->last];

        	ri->last++;
		if (ri->last == NUM_BUF)
			ri->last = 0;
	}
	else bufsize = *total_len = 0;
   return bufsize;
}

int
pcap_read(pcap_t *p, int cnt, pcap_handler callback, u_char *user)
{
// p          net device description structure
// cnt        numver of packets to read
// callback   callback function provided by user and invoked here
// user	      parameter to the callback function
        int cc;
	register struct bpf_insn *fcode = p->fcode.bf_insns;
//	register struct bpf_insn *fcode = NULL;

	register u_char *bp ;
	register int caplen;
	volatile short read_errno=0;

	caplen = p->cc;
	if (caplen == 0)
	{
                caplen = pkt_read(p->fd, (char *)p->buffer, p->bufsize, &cc);
                read_errno = pkt_errno;
                if (caplen==0)
        	   return 0;
                if (caplen < 0 || read_errno > 0)
                {    // error ?
        	      if (errno == EWOULDBLOCK) // nonblocking mode ?
                         return (0);
                      else
        	        sprintf(p->errbuf, "pcap_read: %s",pcap_strerror(errno));
        	        return (-1);
                }
	        bp = p->buffer;    //bp points to the start of the buffer
        } else
                bp = p->bp;
#if defined DEBUG
	dump_bytes(bp,caplen);
#endif
	++p->md.stat.ps_recv;
	if (caplen > p->snapshot)
		caplen = p->snapshot;
	if (bpf_filter(fcode, bp,cc, caplen)) {
		struct pcap_pkthdr h;
		gettimeofday(&h.ts,NULL);
		h.len = cc;
		h.caplen = caplen;
		(*callback)(user, &h, bp);
	}
	p->cc = 0;
	return (1);
}

pcap_t *
pcap_open_live(char *device, int snaplen, int promisc, int to_ms, char *ebuf)
// open device
// device     - device used for receiver
// snaplen    -	max packet size
// promisc    - promisc mode on/off
// to_ms      // not implemented
// ebuf       - error buf
//XXX currently only ethernet is handled
{
	register pcap_t *p;
	short pktint[MAX_PKTS];
        struct device_descr *d;
	short device_number;
        short number=0; 

        if (strncmp("eth",device,3) != 0)
        {
		strcpy(ebuf, "invalid device");
		return NULL;
        } else
		number = atoi(device+3);

        for (device_number = 0; device_number < MAX_DEVICES; device_number++) 
	{
	
        	d = &devices[device_number];
        	if (d->valid ==DEVICE_MAGIC_NUMBER) 
			continue;
        	if (d->valid !=DEVICE_MAGIC_NUMBER) 
			break;
		strcpy(ebuf, "bad device status");
		return NULL;
        }

       	if (d->valid ==DEVICE_MAGIC_NUMBER) {
		strcpy(ebuf, "out of devices");
		return NULL;
	}
			
	bzero(d, sizeof(*d));

        if (device == NULL)	// enhancement
        {
                d->recv_info.receiver = receiver_null;
                d->recv_info.start = receiver_null_start;
                d->recv_info.end = receiver_null_end;
                strcpy(d->name,"eth0");         //eth0
                d->eth=0;
        } else	
	{
		switch (device_number)
		{
#define	RI	d->recv_info
#define CASE_RECEIVER(num)				\
	case num :					\
	{						\
	       	RI.receiver = receiver_##num##;		\
		RI.start = receiver_##num##_start;	\
       	        RI.end = receiver_##num##_end;		\
		break;					\
	}

			CASE_RECEIVER(0)
			CASE_RECEIVER(1)
			CASE_RECEIVER(2)
			CASE_RECEIVER(3)
			CASE_RECEIVER(4)
			CASE_RECEIVER(5)
			CASE_RECEIVER(6)
			CASE_RECEIVER(7)
			default:
			{
				strcpy(ebuf, "out of devices");
				return NULL;
			}
		}
		RI.buffer_length = PACKET_BUF_SIZE;	
	        strcpy(d->name,device);         	
		d->eth=number;				

	}
	if (driver_installed(pktint) >=d->eth)
		d->intno = pktint[d->eth];
        else {
		strcpy(ebuf, "No packet driver found");
		return NULL;
        }

	p = (pcap_t *)malloc(sizeof(*p));
	if (p == NULL) {
		strcpy(ebuf, pcap_strerror(errno));
		return (NULL);
	}

	bzero(p, sizeof(*p));
	if (( d->handle = access_type(d->intno,                      // XXX
		CL_ETHERNET,	/* has to be an Ethernet driver */
		0xffff,	        /* we don't care whose it is. */
		d->eth,	        /* we want the right piece of hardware */
		NULL,	       	/* doesn't matter because we want all */
		0,	       	/* zero type length, that is, all. */
		&d->recv_info)) == -1)	/* -> our upcall */
	{
		sprintf(ebuf, "Error: access type\n%s",PacketErrorDescr());
		goto bad;
	}

	/* put the interface into promiscuous mode */

        p->fd=device_number;
	p->snapshot = snaplen;
	p->linktype = DLT_EN10MB;
	p->bufsize = PACKET_BUF_SIZE+1;		//XXX
	p->buffer = (u_char *)malloc(p->bufsize);
	if (p->buffer == NULL) {
		strcpy(ebuf, pcap_strerror(errno));
		goto bad;
	}

        if(promisc) {
		if ((d->oldmode =
                   set_mode(d->intno,d->handle,RECV_PROMISCUOUS)) == -1)  {
	              sprintf(ebuf, "Warning: set_mode%s",PacketErrorDescr());
		      d->mode = RECV_UNCHANGED;
                      goto bad;
		}
	        d->mode = RECV_PROMISCUOUS;
        } else
	        d->mode = RECV_UNCHANGED;

	atexit(restore_mode);
        d->valid=DEVICE_MAGIC_NUMBER;
	return (p);
bad:
        if (p->fd >= 0)
        {
                set_mode(d->intno,d->handle,d->oldmode);
                release_type(d->intno, d->handle);
        }
	if (p->buffer != NULL)
		free(p->buffer);
	free(p);
	return (NULL);
}

int
pcap_setfilter(pcap_t *p, struct bpf_program *fp)
{
	p->fcode = *fp;
	return (0);
}
