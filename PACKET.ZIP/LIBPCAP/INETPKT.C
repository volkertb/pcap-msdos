#include "pcap-dos.h"
#include <sys/param.h>
#include <sys/file.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#ifdef HAVE_SYS_SOCKIO_H
#include <sys/sockio.h>
#endif
#include <sys/time.h>				/* concession to AIX */

#include <net/if.h>
#include <netinet/in.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include "pcap-int.h"

/*
 * Return the name of a network interface attached to the system, or NULL
 * if none can be found.  The interface must be configured up; the
 * lowest unit number is preferred; loopback is ignored.
 */
char *
pcap_lookupdev(errbuf)
	register char *errbuf;
{
	short pktint[8];

	if (driver_installed(pktint) >0)
	   return "eth0";
        else {
	   strcpy(errbuf, "No packet driver found");
           return NULL;
        }
}

int
pcap_lookupnet(device, netp, maskp, errbuf)
	register char *device;
	register bpf_u_int32 *netp, *maskp;
	register char *errbuf;
{
	static u_char pktdrv_netp[4] = {192,0,0,1};
	static u_char pktdrv_maskp[4] = { 255,255,255,0};

	*netp  = (bpf_u_int32)pktdrv_netp ;
	*maskp = (bpf_u_int32)pktdrv_maskp ;
	if (*maskp == 0) {
		if (IN_CLASSA(*netp))
			*maskp = IN_CLASSA_NET;
		else if (IN_CLASSB(*netp))
			*maskp = IN_CLASSB_NET;
		else if (IN_CLASSC(*netp))
			*maskp = IN_CLASSC_NET;
		else {
			(void)sprintf(errbuf, "inet class for 0x%x unknown",
			    *netp);
			return (-1);
		}
	}
	*netp &= *maskp;
	return (0);
}
