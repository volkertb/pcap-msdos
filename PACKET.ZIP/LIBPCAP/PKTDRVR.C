/*
 * Written for DJGPP by 
 * Wojciech Galazka <wgalazka@chem.uw.edu.pl>
 */
char Copyright[] = "Copyright (C) 1997,1998 Wojciech Galazka";
#include <assert.h>
#include <stdio.h>
#include <dos.h>
#include <string.h>
#include <dpmi.h>
#include <go32.h>
#include "pktdrvr.h"

#if !defined OFFSET
#define OFFSET(seg,ofs) (((seg)<< 4) + ofs)
#endif

struct info
{
	short handle;				/* receiver/sender id */
	short intno;				/* interrupt number */
	_go32_dpmi_seginfo handler;		/* receiver handler */
	_go32_dpmi_registers regs;		/* receiver registers */
	_go32_dpmi_seginfo meminfo[NUM_BUF];	/* packet buffer meminfo */
};

static struct info recv_info[MAX_PKTS];	/* receiver table */
static struct info send_info[MAX_PKTS];	/* sender table */
static const char pktsig[] = "PKT DRVR";/* Packet driver signature */

static short recv_count=0,send_count=0;

unsigned short pkt_errno = 0;

static const char  * PacketErrList[] =
	{" No error ",
	 " Invalid handle number ",
	 " No interfaces of specified class found ",
	 " No interfaces of specified type found ",
	 " No interfaces of specified number found ",
	 " Bad packet type specified ",
	 " This interface does not support multicast ",
	 " This packet driver cannot terminate ",
	 " An invalid receiver mode was specified ",
	 " Operation failed because of insufficient space ",
	 " The type had previously been accessed, and not released ",
	 " The command was out of range, or not implemented ",
	 " The packet couldn't be sent (usually hardware error) ",
	 " Hardware address couldn't be changed (> 1 handle open) ",
	 " Hardware address has bad length or format ",
	 " Couldn't reset interface (> 1 handle open) ",
	 " Out of resources"
	 " Error out of range "};

const char * PacketErrorDescr(void)
{
	unsigned short error = (pkt_errno > 17)? 17: pkt_errno;
        return PacketErrList[error];
}


int packet_installed (short intno) 	/* interrupt number */
{
	char sig[8];	
	int length = strlen(pktsig);
	__dpmi_raddr addr;
	__dpmi_get_real_mode_interrupt_vector(intno,&addr);
	dosmemget(OFFSET(addr.segment,addr.offset16+3),length,sig);
	return !strncmp(sig,pktsig,length);
}

int driver_installed(short *p)
{
	char sig[8];
	short intno;
	short num=0;
	const int length = strlen(pktsig);
   	assert (p !=NULL);
	for (intno = 0x60; intno < 0x80; intno++) 
	{
		__dpmi_raddr addr;
		__dpmi_get_real_mode_interrupt_vector(intno,&addr);
		dosmemget(OFFSET(addr.segment,addr.offset16+3),length,sig);
		if (!strncmp(sig,pktsig,length))
		{
			p[num++]=intno;
			if (num == MAX_PKTS)
				return num;
		}
	}
	return num;
}

int driver_info(short intno,
        short handle,    	 	/* handle */
        short *version,   		/* version */
        short *class,     		/* class */
        short *type,      		/* type */
        short *number,    		/* interface nuber */
        char  *name,   			/* driver name */
        short *function)  		/* functionality */
{
	__dpmi_regs regs;
	regs.x.ds = (__tb >> 4) & 0xffff;
	regs.x.si = __tb & 0x0f;
	regs.x.bx = handle;
	regs.h.ah = DRIVER_INFO;
	regs.h.al = 0xff;
	__dpmi_int(intno,&regs);
	if(regs.x.flags & 1)
	{
		pkt_errno = regs.h.dh;
		return -1;
	}
        if (version != NULL)
        	*version = regs.x.bx;
        if (class != NULL)
        	*class = regs.h.ch;
        if (type != NULL)
        	*type = regs.x.dx;
        if (number != NULL)
        	*number = regs.h.cl;
        if (function != NULL)
        	*function = regs.h.al;
        if (name !=NULL)
        	dosmemget(OFFSET(regs.x.ds, regs.x.si),PKT_NAME_LENGTH,name);
	return 0;
}

short access_type (short intno,  	/* interrupt number */
	short if_class,         	/* class */
	short if_type,          	/* type */
	short if_number,        	/* interface number, first=0 */
	char  *type,         		/* ptr to packet type specs */
	unsigned short typelen, 	/* = sizeof(*type) */
	struct receiver_info *r)	/* packet receiver function */
{
	__dpmi_regs regs;
	int i;
	struct info *rec;
   	if (recv_count == MAX_PKTS)
	{
     		pkt_errno = PKT_NO_RESOURCES;
     		return -1;
   	}
	if ((r == NULL) || (r->receiver == NULL) || (r->buffer_length ==0))
	{
		pkt_errno=PKT_BAD_MODE;
		return -1;
	}
	rec= &recv_info [recv_count];
	if (type != NULL)
		dosmemput(type, typelen,__tb);
	rec->handler.pm_offset=(int)r->receiver;
	for (i=0; i<NUM_BUF; i++)
	{
		rec->meminfo[i].size=(r->buffer_length+15)/16;
		_go32_dpmi_allocate_dos_memory(&rec->meminfo[i]); 
		r->seg[i] = rec->meminfo[i].rm_segment;
	   	r->ofs[i] = 0;
	   	r->packet_length[i] =0;
	}
	r->used =0;
	r->last =0;
	_go32_dpmi_lock_code(r->receiver,(unsigned)r->end-(unsigned)r->start);
	_go32_dpmi_allocate_real_mode_callback_retf(&rec->handler, &rec->regs);
	regs.x.es = rec->handler.rm_segment;
	regs.x.di = rec->handler.rm_offset;
	regs.x.ds = (__tb >> 4) & 0xffff;
	regs.x.si = __tb & 0x0f;
	regs.h.dl = if_number;		/* Number */
	regs.x.cx = typelen;		/* Length of type */
	regs.x.bx = if_type;		/* Type */
	regs.h.ah = ACCESS_TYPE;	/* Access_type() function */
	regs.h.al = if_class;		/* Class */
	__dpmi_int(intno,&regs);
	if(regs.x.flags & 1)
	{
		pkt_errno = regs.h.dh;
		return -1;
	}
	rec->handle=regs.x.ax;
	rec->intno=intno;
	recv_count++;
	return (regs.x.ax);
}

/* the (intno, handle) pair uniquely identifies the proper interface */
static void release_callbacks(const short intno, const short handle)
{
  	int i,j,k;
        k=recv_count;
  	for (i=0; i < k ; i++)
	{
		struct info *rec=&recv_info[i];
		if ((rec->intno=intno) && 
			(handle == 0xFF || handle == rec->handle))
    		{
    			_go32_dpmi_free_real_mode_callback(&rec->handler);
			for (j=0; j<NUM_BUF; j++)
	    			_go32_dpmi_free_dos_memory(&rec->meminfo[j]); 
	    		rec->handle = rec->intno = 0;
	    		recv_count--;
    		}
	}
        k=send_count;
  	for (i=0; i < k ; i++)
	{
		struct info *send=&send_info[i];
		if ((send->intno == intno) &&
			(handle == 0xFF || handle == send->handle))
  	 	{
	    		_go32_dpmi_free_real_mode_callback(&send->handler);
    			_go32_dpmi_free_dos_memory(&send->meminfo[0]); 
    			send->handle = send->intno = 0;
    			send_count--;
  	 	}
	}
}

int release_type (short intno, 		/* interrupt number */
	short handle)         		/* handle */
{					
	__dpmi_regs regs;
	regs.x.bx = handle;
	regs.h.ah = RELEASE_TYPE;
	__dpmi_int(intno,&regs);
	if(regs.x.flags & 1)
	{
		pkt_errno = regs.h.dh;
		return -1;
	}
   	release_callbacks(intno, handle);
	return 0;
}

int send_pkt (short intno,     		/* interrupt number */
	char  *buffer,       		/* ptr to the packet buffer */
	unsigned short length) 		/* length of the buffer */
{
	__dpmi_regs regs;
	if (buffer == NULL || length == 0)
	      return 0;			//nothing sent
  	dosmemput(buffer, length,__tb);
	regs.x.ds = (__tb >> 4) & 0xffff;
	regs.x.es = (__tb >> 4) & 0xffff;
	regs.x.si = __tb & 0x0f;
	regs.x.cx = length;
	regs.h.ah = SEND_PKT;
	__dpmi_int(intno,&regs);
	if(regs.x.flags & 1)
	{
		pkt_errno = regs.h.dh;
		return -1;
	}
	return 0;
}

int terminate (short intno, 		/* interrupt number */
	short handle)          		/* handle */
{
	__dpmi_regs regs;
	regs.x.bx = handle;
	regs.h.ah = TERMINATE;
	__dpmi_int(intno,&regs);
	if(regs.x.flags & 1)
	{
		pkt_errno = regs.h.dh;
		return -1;
	} 
   	release_callbacks(intno, 0xFF);	//terminate driver
	return 0;
}

short get_address (short intno,  	/* interrupt number */
	short handle,           	/* handle */
	char  *buf,          		/* buffer to hold the address */
	unsigned short length)    	/* buffer length */
{
	__dpmi_regs regs;
   	if (buf == NULL)
	{
		pkt_errno=PKT_NO_SPACE;
		return -1;
	}
	regs.x.es = (__tb >> 4) & 0xffff;
	regs.x.di = __tb & 0x0f;
	regs.x.cx = length;
	regs.x.bx = handle;
	regs.h.ah = GET_ADDRESS;
	__dpmi_int(intno,&regs);
	if(regs.x.flags & 1){
		pkt_errno = regs.h.dh;
		return -1;
	}
 	dosmemget(__tb, length, buf);
  	return regs.x.cx;
}

int reset_interface (short intno,/* interrupt number */
	short handle)           /* handle */
{
	__dpmi_regs regs;
	regs.x.bx = handle;
	regs.h.ah = RESET_INTERFACE;
	__dpmi_int(intno,&regs);
	if(regs.x.flags & 1){
		pkt_errno = regs.h.dh;
		return -1;
	}
	return 0;
}

/* HIGH PERFORMANCE DRIVER FUNCTIONS */

int get_parameters(short intno,
        struct param *s)
{
	__dpmi_regs regs;
   	if (s == NULL)
	{
		pkt_errno=PKT_NO_SPACE;
		return -1;
	}
	regs.x.es = (__tb >> 4) & 0xffff;
	regs.x.di = __tb & 0x0f;
	regs.h.ah = GET_PARAMETERS;
	__dpmi_int(intno,&regs);
	if(regs.x.flags & 1){
		pkt_errno = regs.h.dh;
		return -1;
	}
	dosmemget(OFFSET(regs.x.es, regs.x.di), sizeof(*s),s);
	return 0;
}

unsigned short get_mtu(short intno)
{
	struct param prm;
        return (get_parameters(intno, &prm) == -1) ? 0 : prm.mtu;
}

int old_as_send_pkt (short intno,  	/* interrupt number */
	short handle,			/* handle */
	char  *buffer,       		/* ptr to the packet buffer */
   	unsigned short length,  	/* buffer length */
	struct sender_info *r)		/* packet sender function */
{
	__dpmi_regs regs;
	struct info *send;
   	assert(r != NULL);
	if (buffer == NULL || length ==0)                 //nothing sent
		return 0;
   	if (send_count == MAX_PKTS)
	{
	     	pkt_errno = PKT_NO_RESOURCES;
     		return -1;
   	}
	if ((r == NULL) || (r->sender == NULL))
	{
		pkt_errno=PKT_BAD_MODE;
		return -1;
	}
	send=&send_info[send_count];
	dosmemput(buffer, length,__tb);
   	r->locked =0;
	send->handler.pm_offset=(int)r->sender;
	send->meminfo[0].size=(r->buffer_length+15)/16;
	_go32_dpmi_allocate_dos_memory(&send->meminfo[0]); 
	r->seg = send->meminfo[0].rm_segment;
   	r->ofs = 0;
   	r->packet_length =0;
       _go32_dpmi_lock_code(r->sender,(unsigned)r->end - (unsigned)r->start);
       _go32_dpmi_allocate_real_mode_callback_retf(&send->handler, &send->regs);
	regs.x.ds = (__tb >> 4) & 0xffff;
	regs.x.si = __tb & 0x0f;
	regs.x.cx = length;
	regs.h.ah = OLD_AS_SEND_PKT;
	__dpmi_int(intno,&regs);
	if(regs.x.flags & 1)
	{
		pkt_errno = regs.h.dh;
		return -1;
	}
	send->handle=handle;
	send->intno=intno;
	send_count++;
	return 0;
}

/* EXTENDED DRIVER FUNCTIONS */

int set_rcv_mode(short intno,  		/* interrupt number */
        short handle,          		/* handle */
        short mode)           	 	/* receive mode */
{
	__dpmi_regs regs;

	if (mode == RECV_UNCHANGED)
		return RECV_UNCHANGED;

	regs.h.ah = SET_RCV_MODE;
	regs.x.cx = mode;
	regs.x.bx = handle;
	__dpmi_int(intno,&regs);
	if(regs.x.flags & 1)
	{
		pkt_errno = regs.h.dh;
		return -1;
	}
   	return 0;
}

short get_rcv_mode(short intno,		/* interrupt number */
        short handle)           	/* handle */
{
	__dpmi_regs regs;
	regs.h.ah = GET_RCV_MODE;
	regs.x.bx = handle;
	__dpmi_int(intno,&regs);
	if(regs.x.flags & 1)
	{
		pkt_errno = regs.h.dh;
		return -1;
	}
  	return regs.x.ax;
}

short set_mode (short intno,   		/* interrupt number */
	short handle,           	/* handle */
	short mode)            		/* mode */
{
	short oldmode;
	if (mode == RECV_UNCHANGED)
		return RECV_UNCHANGED;
   	if ((oldmode = get_rcv_mode(intno,handle)) == -1)
      		return -1;
   	if (set_rcv_mode(intno,handle,mode) == -1)
      		return -1;
   	return oldmode;
}

int set_multicast_list(short intno,   	/* interrupt number */
      char  *buf, 			/* multicast addresses */
      unsigned short length)   		/* buffer length */
{
	__dpmi_regs regs;
	if (buf != NULL && length > 0)
    		dosmemput(buf, length,__tb);
	regs.x.es = (__tb >> 4) & 0xffff;
	regs.x.di = __tb & 0x0f;
	regs.x.cx = length;
	regs.h.ah = SET_MULTICAST_LIST;
	__dpmi_int(intno,&regs);
	if(regs.x.flags & 1)
	{
		pkt_errno = regs.h.dh;
		return -1;
	}
	return 0;
}

int get_multicast_list(short intno,  	/* interrupt number */
	char  *buf,			/* buffer */
	unsigned short * length)   	/* buffer length */
{
	__dpmi_regs regs;
   	if (buf == NULL || length == NULL)
	{
		pkt_errno=PKT_NO_SPACE;
		return -1;
	}
	regs.x.es = (__tb >> 4) & 0xffff;
	regs.x.di = __tb & 0x0f;
	regs.h.ah = GET_MULTICAST_LIST;
	__dpmi_int(intno,&regs);
	if(regs.x.flags & 1)
	{
		pkt_errno = regs.h.dh;
		return -1;
	}
   	*length = regs.x.cx;
   	dosmemget(OFFSET(regs.x.es, regs.x.di), *length,buf);
	return 0;
}

int get_statistics(short intno,   	/* interrupt number */
        short handle,            	/* handle */
	struct statistics  * s)
{
	__dpmi_regs regs;
   	if(s == NULL)
	{
		pkt_errno=PKT_NO_SPACE;
		return -1;
	}
	regs.x.ds = (__tb >> 4) & 0xffff;
	regs.x.si = __tb & 0x0f;
	regs.x.bx = handle;
	regs.h.ah = GET_STATISTICS;
	__dpmi_int(intno,&regs);
	if(regs.x.flags & 1){
		pkt_errno = regs.h.dh;
		return -1;
	}
	dosmemget(OFFSET(regs.x.ds, regs.x.si), sizeof(*s),s);
	return 0;
}

int set_address(short intno,   		/* interrupt number */
        char  *buf,         		/* buffer holding the address */
	unsigned short *length)		/* buffer lengrh*/
{
	__dpmi_regs regs;
	if (buf != NULL && length != NULL)
		dosmemput(buf, *length,__tb);
	regs.x.es = (__tb >> 4) & 0xffff;
	regs.x.di = __tb & 0x0f;
	regs.x.cx = *length;
	regs.h.ah = SET_ADDRESS;
	__dpmi_int(intno,&regs);
	if(regs.x.flags & 1){
		pkt_errno = regs.h.dh;
		return -1;
	}
	*length= regs.x.cx;
	return 0;
}
